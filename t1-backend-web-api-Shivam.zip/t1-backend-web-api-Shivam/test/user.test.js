const supertest = require("supertest");
const app = require("../app");

const api = supertest(app);
// User Model
const User = require("../models/userModel");
// To execute function. [find() , findOne() , deleteMany()]
const mongoose = require("mongoose");

const user = {
    username: "test",
    email: "test@gmail.com",
    password: "test"
};


const loginUser = {
    username: "test",
    password: "test"
};


beforeAll(async () => {
    await User.deleteMany({});
});


test("register user testing", async () => {
    await api.post("/api/user/registeruser").send(user).expect(200);
});


test("Testing login for user", async () => {
    await api
        .post("/api/user/loginuser")
        .send(loginUser)
        .expect(200)
});



afterAll(async () => {
    await mongoose.connection.close();
});